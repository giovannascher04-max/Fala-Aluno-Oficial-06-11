# Guia do grupo – Fala Aluno

Este guia tem duas partes: **como colocar o site no ar** (uma vez só) e **como o código funciona** (para vocês explicarem no TCC).

## 1. O que é cada arquivo

| Arquivo | Para que serve |
| --- | --- |
| `index.html` | A página do site: estrutura e textos |
| `style.css` | O visual: cores, fontes e disposição na tela |
| `config.js` | **O único arquivo que vocês mexem**: e-mail da escola e dados do Firebase |
| `exemplos.js` | Avisos e aulas de exemplo, usados enquanto o Firebase não está ligado |
| `script.js` | Lê os avisos e as aulas do Firebase e mostra na página |
| `admin.html` | A área do administrador: tela de login e formulários |
| `admin.js` | O programa da área do administrador: login, adicionar, editar, esconder e apagar |

## 2. Colocar o site no ar

### Passo 1 – Criar o projeto no Firebase

1. Entre em **console.firebase.google.com** com uma conta Google do grupo e clique em **Criar um projeto**. Pode desativar o Google Analytics.
2. Na tela inicial do projeto, clique no ícone **`</>`** (app da Web), dê um apelido (por exemplo, `fala-aluno`) e registre. **Não** precisa marcar o Firebase Hosting.
3. O Firebase mostra um bloco `firebaseConfig`. Copie `apiKey`, `authDomain`, `projectId` e `appId` para o `FIREBASE_CONFIG` do arquivo `config.js`.
4. Troque também `EMAIL_DA_ESCOLA` por um e-mail da escola ou do grêmio (ele fica visível no código, então **não usem e-mail pessoal**).

### Passo 2 – Ligar o login

1. No menu do Firebase: **Criação → Authentication → Vamos começar**.
2. Em **Sign-in method**, ative **E-mail/senha**.
3. Na aba **Users**, clique em **Adicionar usuário** e cadastre o e-mail e a senha do administrador. Repita para cada pessoa que vai atualizar o site.

### Passo 3 – Criar o banco de dados

1. No menu: **Criação → Firestore Database → Criar banco de dados**.
2. Escolha o local **southamerica-east1 (São Paulo)**. Depois de criado, o local não muda.
3. Escolha **Iniciar no modo de produção** e conclua.

### Passo 4 – Colocar as regras de segurança

Esta é a parte que protege o site. Sem ela, qualquer pessoa poderia mudar os avisos.

1. No Firestore, abra a aba **Regras**.
2. Apague tudo, cole o texto abaixo e troque os e-mails pelos dos administradores cadastrados no Passo 2.
3. Clique em **Publicar**.

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    function ehAdmin() {
      return request.auth != null
        && request.auth.token.email in ['admin@exemplo.com', 'outra.pessoa@exemplo.com'];
    }

    match /avisos/{id} {
      allow read: if resource.data.mostrar == true || ehAdmin();
      allow write: if ehAdmin();
    }

    match /aulas/{id} {
      allow read: if resource.data.mostrar == true || ehAdmin();
      allow write: if ehAdmin();
    }
  }
}
```

Para tirar o acesso de alguém, remova o e-mail desta lista e publique de novo.

### Passo 5 – Colocar no Vercel

1. Coloquem estes sete arquivos em um repositório do GitHub (ou enviem direto pela Vercel): `index.html`, `admin.html`, `style.css`, `config.js`, `exemplos.js`, `script.js` e `admin.js`.
2. Na Vercel: **Add New → Project**, escolha o repositório e clique em **Deploy**. Não precisa mudar nenhuma configuração.
3. A página dos administradores é o endereço do site seguido de `/admin.html`.

### Passo 6 – Testar

- Abra `/admin.html`, entre com o e-mail e a senha e cadastre um aviso. Ele deve aparecer no `index.html` ao recarregar.
- Clique em **Esconder** e veja se o aviso some do site.
- Tente entrar com uma senha errada: deve aparecer "E-mail ou senha incorretos."
- Abra o site sem estar logado: avisos escondidos não podem aparecer.

Quando o Firebase é ligado, os exemplos deixam de aparecer. O site fica vazio até o administrador cadastrar o primeiro aviso.

## 3. Problemas comuns

| O que aconteceu | O que fazer |
| --- | --- |
| Aparecem avisos com a etiqueta “exemplo” | `apiKey` ainda está vazio no `config.js` |
| “Não foi possível carregar os avisos” | Conferir os dados do `FIREBASE_CONFIG` e se as regras foram publicadas (Passo 4) |
| No painel: “Não foi possível concluir” | O e-mail com que você entrou não está na lista das regras |
| “E-mail ou senha incorretos” | Conferir o usuário em Authentication → Users |
| A página do administrador mostra só um aviso amarelo | Falta preencher o `config.js` |
| Aula aparece fora de ordem | O campo Hora precisa ter o mesmo formato nas aulas do dia (por exemplo, `13h30`) |

## 4. Como o código funciona (para o TCC)

O caminho de um aviso, do administrador até a tela do aluno:

1. A pessoa entra em `admin.html`. O `admin.js` usa o **Firebase Authentication** (`signInWithEmailAndPassword`) para conferir e-mail e senha.
2. Ao salvar o formulário, o `admin.js` grava um documento na coleção `avisos` do **Firestore** (`add` para novo, `update` para editar).
3. O `script.js`, na página do aluno, busca os documentos com `mostrar == true` (`where`).
4. As funções `mostrarAvisos` e `mostrarAulas` criam os cartões na página com `document.createElement`.

Decisões que vale explicar:

- **A segurança está nas regras do Firestore, não no JavaScript.** Os dados do `config.js` ficam visíveis para qualquer pessoa, e isso é normal no Firebase. O que impede alguém de escrever é a regra `ehAdmin()`, que roda nos servidores do Google. Esconder o botão no código não seria proteção.
- **A regra usa a lista de e-mails, e não “qualquer usuário logado”.** Assim, mesmo que alguém consiga criar uma conta, não consegue editar nada.
- **`textContent` em vez de `innerHTML`.** O texto digitado aparece como texto, mesmo se alguém digitar `<` e `>`. Um aviso mal digitado não quebra a página.
- **O mesmo código serve para avisos e aulas.** O objeto `TIPOS` do `admin.js` diz quais campos cada coleção tem.
- **Sem servidor próprio.** O site continua sendo só arquivos estáticos na Vercel; o Firebase faz o papel de servidor.

Limitações para colocar nas considerações finais:

- O Firebase tem plano gratuito com limite de uso, suficiente para uma escola, mas existe.
- A lista de administradores fica nas regras do Firestore e precisa ser mudada no console do Firebase.
- As sugestões dos alunos continuam indo por e-mail, e não ficam guardadas no site.
- Não há recuperação de senha na tela; o administrador pode redefinir a senha pelo console do Firebase.
